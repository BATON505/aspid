﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Exam_RykulinIM
{
    public partial class Web_RykulinIM : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LoadDataButton_Click(object sender, EventArgs e)
        {
            LoadDataButton.Visible = false;
            LoadDataLabel.Visible = false;

            DataDropDownList.Visible = true;
            DataLabel.Visible = true;
        }

        protected void DataDropDownList_TextChanged(object sender, EventArgs e)
        {
            string oldSelect = SqlDataSource1.SelectCommand;

            //SqlDataSource1.SelectCommand = "Select [au_lname], [address], [phone] from [authors] where [au_lname] = \'" + DataDropDownList.Text + "\'";
            DataView dataView = (DataView)SqlDataSource1.Select(DataSourceSelectArguments.Empty);

            //SqlDataSource1.SelectCommand = "Select [au_lname], [address], [phone] from [authors]";
            string address = "";

            //SqlDataSource1.SelectCommand = "Select [phone] from [authors] where [au_lname] = " + DataDropDownList.Text;
            string phone = "";
            //DataLabel.Text = string.Format("Address: {0}, Phone: {1}", dataView[0][0].ToString(), dataView[0][1].ToString());

            foreach(DataRowView row in dataView)
            {
                if (row["au_lname"].ToString() == DataDropDownList.Text)
                {
                    address = row["address"].ToString();
                    phone = row["phone"].ToString();
                }
            }

            DataLabel.Text = string.Format("Address: {0}, Phone: {1}", address, phone);

            SqlDataSource1.SelectCommand = oldSelect;
        }
    }
}